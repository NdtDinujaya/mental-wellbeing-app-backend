package com.example.Mental_Health;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MentalHealthApplicationTests {

	@Test
	void contextLoads() {
	}

}
